from flask import Flask, render_template, request, redirect, url_for
from todo import TodoItem


app = Flask(__name__)
app.lista = list()


@app.route('/')
def index():
    #print('Hola Flask')
    return '<h1>Hola Flask</h1>'


@app.route('/saludo')
def saludo():
    return 'Hola, cómo andás!?'


@app.route('/lista')
def todo_index():
    print(app.lista)
    return render_template('lista_index.html', lista=app.lista)


@app.route('/lista/crear', methods=('GET', 'POST'))
def crear_tarea():
    if request.method == 'POST':
        nombre_tarea = request.form['nombre']
        nueva_tarea = TodoItem(nombre_tarea)
        app.lista.append(nueva_tarea)
        return redirect(url_for('todo_index'))
    return render_template('crear_tarea.html')


@app.route('/lista/<int:tarea_id>/avanzar')
def avanzar_estado(tarea_id):
    app.lista[tarea_id].avanzar_estado()
    return redirect(url_for('todo_index'))


@app.route('/lista/<int:tarea_id>/cambiar', methods=('GET', 'POST'))
def cambiar_estado(tarea_id):
    if request.method == 'POST':
        nuevo_estado = request.form['estado']
        app.lista[tarea_id].cambiar_estado(nuevo_estado)
        return redirect(url_for('todo_index'))
    return render_template('cambiar_estado.html', tarea=app.lista[tarea_id])


@app.route('/lista/<int:tarea_id>')
def borrar(tarea_id):
    app.lista.pop(tarea_id)
    return redirect(url_for('todo_index'))


if __name__ == '__main__':
    app.run(debug=True)
