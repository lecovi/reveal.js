#!/usr/bin/python

def mensaje1():
        print("Imprimiendo primer mensaje")

def mensaje2():
        print("Imprimiendo el segundo mensaje")

print("Esto se ejecuta siempre")

if __name__ == "__main__":
        print("Esto se imprime si no es una importación")
