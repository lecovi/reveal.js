#!/usr/bin/env python

import funciones

## Ahora podemos utilizar las funciones que hicimos antes.
## Notemos que cuando realizamos el import, se ejecuta todo
## el código anterior!
funciones.imprimir_mensaje()

