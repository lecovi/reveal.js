#!/usr/bin/python
import persona
import reptil

sujeto = persona.Persona("Jorge")
animal = reptil.Reptil("Pitón")

sujeto.avanzar()
animal.avanzar()
