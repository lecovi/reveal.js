#!/usr/bin/env python
from multiple import Empleado

roberta = Empleado('Roberta', 34)
roberta.identidad()
roberta.trabajar()
