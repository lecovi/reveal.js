#!/usr/bin/env python
from trabajador import Trabajador, Jubilado, Menor

nico = Trabajador('Nico')
juan = Jubilado('Juan')
thiago = Menor('Thiago')

nico.trabajar()
juan.trabajar()
thiago.trabajar()
